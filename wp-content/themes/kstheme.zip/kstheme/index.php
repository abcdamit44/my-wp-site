<?php get_header() ?>
<div class="container my-5">
    <h1>Hello, world!</h1>

</div>

<?php get_footer() ?>