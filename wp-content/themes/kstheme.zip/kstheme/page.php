<?php get_header() ?>

<div class="container my-5">
    <?php
    the_content();
    ?>

</div>

<?php get_footer() ?>