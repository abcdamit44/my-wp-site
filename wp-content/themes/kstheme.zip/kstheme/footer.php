
<footer class="bg-dark text-center p-3 text-white">
    Copyright &copy; All Rights Reserved.
</footer>

<!-- Optional JavaScript; choose one of the two! -->

    <?php wp_footer() ?>
  </body>
</html>